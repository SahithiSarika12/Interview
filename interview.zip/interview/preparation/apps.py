from django.apps import AppConfig


class PreparationConfig(AppConfig):
    name = 'preparation'
